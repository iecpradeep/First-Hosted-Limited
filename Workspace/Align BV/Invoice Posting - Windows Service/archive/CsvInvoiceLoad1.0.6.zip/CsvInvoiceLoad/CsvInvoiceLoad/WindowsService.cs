﻿/*******************************************************
 * Name:		CsvInvoiceLoad
 * Type:    	.net 2 - Windows Service
 *
 * Version:	1.0.1 – 27/06/2012 – 1st release - AS
 *          1.0.2 - 28/06/2012 - amended - read file amendment JM	
 *          1.0.3 - 02/07/2012 - amended - change the framework version to 2.0,
 *                                          change the installation path,
 *                                          remove some references 
 *                                          make the service automatically start after installation AS
 *          1.0.4 - 24/07/2012 - amended - deal with credit notes, i.e. check for change of invoice+creditnote number  
 *          1.0.5 - 30/07/2012 - amended - change schedule to start immediatly rather than after the scheduled has transpired
 *          1.0.6 - 1/08/2012  - amended - if move file fails, delete the source file - the file will already be in the archive or failure directory
 *           
 * Author:	FHL
 * Purpose:	Windows Service to post a CSV payload into NetSuite using a REST Web Service.
 *******************************************************/


using System;
using System.Timers;
using System.ServiceProcess;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Configuration;
using System.Net;
using System.IO;
using System.Collections;


namespace CsvInvoiceLoad
{
    public partial class CsvInvoiceLoad : ServiceBase
    {
        private String URL = "";
        private String account = "";
        private String email = "";
        private String password = "";
        private String role = "";
        private int interval = 0;
        private Timer serviceTimer = new System.Timers.Timer();     //Create a variable to call the Timer object  

        private string contents = "";
        private string invLine = "";
        private StringBuilder invLines = new StringBuilder();
        private string currentInvoiceNo = "";
        private string previousInvoiceNo = "";
        private string creditNote = "";     // 1.0.4
        private string[] splitCSV;

        private const Int32 INV_POS = 4;    // 1.0.4 - deal with credit notes
        private const Int32 CR_POS = 6;     // 1.0.4 - deal with credit notes


        //************************************************************
        //Calling the constructor
        //************************************************************
        public CsvInvoiceLoad()
        {
            //Initializing the components
            InitializeComponent();
            loadConfigValues();
        }


        //************************************************************
        // Define the activities to be done when the service started
        // 1.0.5 interval set to  1 minute so it starts straight away
        //************************************************************
        protected override void OnStart(string[] args)
        {
            // Making the timer to call the elapsed event each time the specified interval elapsed (one minute)
            serviceTimer.AutoReset = true;

            serviceTimer.Interval = 1000 * 60 * 1;          // specifying the interval so the service starts after a minute - then will use the schedule as defined
            serviceTimer.Elapsed += OnElapsedEvent;         // calling the onElapedEvent after the interval has elapsed 
            serviceTimer.Start();                           // Starting the timer
            EventLog.WriteEntry("CSV Service Started");
            
        }


        //************************************************************
        // Define the activities to be done when the service stopped
        //************************************************************
        protected override void OnStop()
        {
            EventLog.WriteEntry("CSV Service Stopped");
            //serviceTimer.Stop(); //Stopping the timer
        }


        //************************************************************
        // Define the activities to be done after each minute
        // 1.0.5 interval set to  1 minute so it starts straight away
        //************************************************************
        private void OnElapsedEvent(object sender, System.Timers.ElapsedEventArgs e)
        {
            EventLog.WriteEntry("CSV Timer Triggered, interval: " + serviceTimer.Interval);
            serviceTimer.Interval = 1000 * 60 * interval;   // specifying the interval
            EventLog.WriteEntry("CSV Timer Triggered, interval: " + serviceTimer.Interval);

            processFiles();
        }


        //************************************************************
        // load configuration values
        //************************************************************
        private void loadConfigValues()
        {
            string environmentKey = "";
            string mode = "";
            string directoryToProcess = "";
            string webService = "";
            environmentKey = ConfigurationSettings.AppSettings["environment"] + "RESTURL";

            mode = ConfigurationSettings.AppSettings["environment"];
            directoryToProcess = ConfigurationSettings.AppSettings["sourceDirectory"];
            webService = ConfigurationSettings.AppSettings[environmentKey];

            interval = Convert.ToInt32(ConfigurationSettings.AppSettings["timinginterval"]);
            URL = webService;
            account = ConfigurationSettings.AppSettings["account"];
            email = ConfigurationSettings.AppSettings["username"];
            password = ConfigurationSettings.AppSettings["password"];
            role = ConfigurationSettings.AppSettings["role"];
        }


        //************************************************************
        // process the files from the source directory
        // 1.0.2 - change read file
        //************************************************************
        private void processFiles()
        {
            string location = ConfigurationSettings.AppSettings["sourceDirectory"];
            string sourceFile = "";
            string destinationFile = "";
            string failureDirectory = "";
            string contents = "";
            string response = "";
            //string preEncoding = "";
            string[] lines;

            try
            {
                System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(location);

                // for each file
                foreach (System.IO.FileInfo f in dir.GetFiles("*.*"))
                {


                    // 1.0.2 add double slashes and readalllines change
                    location = location.Replace(@"\","\\");

                    sourceFile = location + "\\" + f.Name;
                    destinationFile = location + "\\archive\\" + f.Name;
                    failureDirectory = location + "\\failures\\" + f.Name;

                    // Read each line of the file into a string array. Each element of the array is one line of the file.
                    lines = System.IO.File.ReadAllLines(sourceFile);

                    for (int invln = 1; invln <= lines.Length - 1; invln++)
                    {

                        // inv position 5
                        invLine = lines[invln];

                        if (invLine.Length != 0)
                        {

                            splitCSV = invLine.Split(',');
                            currentInvoiceNo = splitCSV[INV_POS];                   // invoice number
                            creditNote = splitCSV[CR_POS];                          // credit note number 1.0.4
                            currentInvoiceNo = currentInvoiceNo + creditNote;       // break on invoice number and credit note number 1.0.4


                            if (currentInvoiceNo == previousInvoiceNo || invln == 1) // || previousInvoiceNo.Length == 0)
                            {
                                previousInvoiceNo = currentInvoiceNo;
                            }
                            else
                            {
                                processInvoiceLine();
                            }

                            invLines.AppendLine(invLine);
                            splitCSV = invLine.Split(',');

                            previousInvoiceNo = splitCSV[INV_POS];                  // invoice number
                            creditNote = splitCSV[CR_POS];                          // credit note number 1.0.4
                            previousInvoiceNo = previousInvoiceNo + creditNote;     // break on invoice number and credit note number 1.0.4

                        }

                    }

                    if (invLines.Length > 0)
                    {
                        response = processInvoiceLine();
                    }

                    // check for success of connecting to the REST web service
                    // if 'success', moving to 'archive' folder 
                    // 1.0.6 - 30/07/2012 - amended - if move file fails, delete the source file - the file will already be in the archive or failure directory

                    try
                    {
                        if (response.Contains("OK"))
                        {
                            moveFile(sourceFile, destinationFile);
                        }
                        //if 'fail', moving to 'failures' folder
                        else
                        {
                            moveFile(sourceFile, failureDirectory);
                        }
                    }
                    catch (Exception e)
                    {
                        EventLog.WriteEntry("Move file failure, deleting file");
                        System.IO.File.Delete(sourceFile);
                    }
                }
            }

            catch (Exception e)
            {
                EventLog.WriteEntry("Service failure: " + e.ToString());
            }

        }


        //************************************************************
        // process each line 
        //************************************************************
        private string processInvoiceLine()
        {

            string response = "";

            // encode the contents ready for transmission
            contents = invLines.ToString();

            contents = encodeCSV(contents);

            invLines.Remove(0, invLines.Length);        // clear all buffer lines
            previousInvoiceNo = "";                     // clear previous invoice number


            // call the rest web service to transfer the payload
            contents = "{\"recordtype\":\"customer\",\"contents\":\"" + contents + "\"}";
            EventLog.WriteEntry("Attempting to call REST Web Service " + @URL);

            response = consumeRESTWebService(contents);

            EventLog.WriteEntry("Web Service Response: " + response + " : " + contents);


            return response;

        }


        //************************************************************
        // move the file to the destination 
        //************************************************************
        private void moveFile(string sourceFile, string destinationFile)
        {
            System.IO.File.Move(sourceFile, destinationFile);
        }


        //************************************************************
        // load a file into a string
        //************************************************************
        private string readFileContents(string fileToRead)
        {
            string contents = "";

            // Read the file as one string.
            System.IO.StreamReader ftr = new System.IO.StreamReader(@fileToRead);
            contents = ftr.ReadToEnd();
            ftr.Close();

            return contents;
        }


        //************************************************************
        // call the netsuite rest web service
        //************************************************************
        private string consumeRESTWebService(string content)
        {

            string responseMessage = "";

            try
            {
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(@URL);
                request.Method = "POST";

                byte[] byteArray = Encoding.UTF8.GetBytes(content);

                String authorization = "NLAuth nlauth_account=" + account + ", nlauth_email=" + email + ",nlauth_signature=" + password + ", nlauth_role=" + role + "";

                request.Headers[HttpRequestHeader.Authorization] = authorization;
                request.Accept = "*.*";
                request.ContentType = "application/json";
                //request.ContentType = "text/plain";
                request.ContentLength = byteArray.Length;

                Stream dataStream = request.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (HttpStatusCode.OK == response.StatusCode)
                {
                    dataStream = response.GetResponseStream();
                    StreamReader reader = new StreamReader(dataStream);

                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        responseMessage = line.ToString();
                    }
                    dataStream.Close();
                    response.Close();
                }
                else
                {
                    responseMessage = "Web Service return code not OK " + response.StatusCode;
                }
            }
            catch (Exception ex)
            {
                responseMessage = ex.Message.ToString();
            }

            return responseMessage;
        }


        //************************************************************
        // encode 
        //************************************************************
        private string encodeCSV(string CSV)
        {
            string retVal = "";

            retVal = CSV
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;")
                .Replace("\"", "&quot;")
                .Replace("'", "&apos;")
                .Replace("\r", "&#xD;")
                .Replace("\n", "&#xA;");

            return retVal;
        }

    }
}
