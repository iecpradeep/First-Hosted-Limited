﻿/*******************************************************
 * Name:		RESTDataTransfer
 * Type:    	.net 2 - Windows Service
 *
 * Version:	1.0.1 – 27/06/2012 – 1st release - AS
 *          1.0.2 - 28/06/2012 - amended - read file amendment JM	
 *          1.0.3 - 02/07/2012 - amended - change the framework version to 2.0,
 *          1.0.4 - 24/07/2012 - amended - deal with credit notes, i.e. check for change of invoice+creditnote number  
 *           
 * Author:	FHL
 * Purpose:	Windows Application to post a CSV payload into NetSuite using a REST Web Service.
 *******************************************************/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Net;
using System.IO;
using System.Collections;

namespace WindowsFormsApplicationRESTDataTransfer
{
    public partial class FormXMLImport : Form
    {

        private String URL = "";
        private String urlParams = "";
        private String account = "";
        private String email = "";
        private String password = "";
        private String role = "";
        private int interval = 0;

        private string contents="";
        private string invLine = "";
        private StringBuilder invLines = new StringBuilder();
        private string currentInvoiceNo = "";
        private string previousInvoiceNo = "";
        private string creditNote = "";     // 1.0.4
        private string[] splitCSV;

        private const Int32 INV_POS = 4;    // 1.0.4 - deal with credit notes
        private const Int32 CR_POS = 6;     // 1.0.4 - deal with credit notes

        //***************************************
        // initialise
        //***************************************
        public FormXMLImport()
        {
            InitializeComponent();
            loadConfigValues();
        }


        //***************************************
        // load configuration values
        //***************************************
        private void loadConfigValues()
        {

            string environmentKey = "";

            environmentKey = ConfigurationSettings.AppSettings["environment"] + "RESTURL";

            textBoxMode.Text = ConfigurationSettings.AppSettings["environment"];
            textBoxDirectoryToProcess.Text = ConfigurationSettings.AppSettings["sourceDirectory"];
            textBoxWebService.Text = ConfigurationSettings.AppSettings[environmentKey];
            richTextBoxWebServiceResult.Text = "";
            richTextBoxXML.Text = "";
            textBoxTimer.Text = ConfigurationSettings.AppSettings["timinginterval"];

            interval = Convert.ToInt32(textBoxTimer.Text);
            URL = textBoxWebService.Text;
            urlParams = "";
            account = ConfigurationSettings.AppSettings["account"];
            email = ConfigurationSettings.AppSettings["username"];
            password = ConfigurationSettings.AppSettings["password"];
            role = ConfigurationSettings.AppSettings["role"];

        }


        //***********************************************
        // process the files from the source directory
        //***********************************************
        
        private void processFiles()
        {
            string location = ConfigurationSettings.AppSettings["sourceDirectory"];
            string sourceFile = "";
            string destinationFile = "";
            string failureDirectory = "";
            string returnValue = "";


            createDirectoryIfItDoesNotExist(location);
            createDirectoryIfItDoesNotExist(location + @"\archive");

            System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(location);



            // for each file

            foreach (System.IO.FileInfo f in dir.GetFiles("*.*"))
            {

                sourceFile = location + @"\" + f.Name;
                destinationFile = location + @"\archive\" + f.Name;
                failureDirectory = location + @"\failures\" + f.Name;
                textBoxFileName.Text = f.Name;
                this.Refresh();

                // read the file contents
                contents = readFileContents(sourceFile);
                richTextBoxXML.Text = contents;
                this.Refresh();

                progressBarFiles.Maximum = richTextBoxXML.Lines.Length-1;

                for(int invln=1;invln<=richTextBoxXML.Lines.Length-1; invln++)
                {

                    // inv position 5

                    invLine = richTextBoxXML.Lines[invln];

                    if (invLine.Length != 0)
                    {

                        splitCSV = invLine.Split(',');
                        currentInvoiceNo = splitCSV[INV_POS];                   // invoice number
                        creditNote = splitCSV[CR_POS];                          // credit note number 1.0.4
                        currentInvoiceNo = currentInvoiceNo + creditNote;       // break on invoice number and credit note number 1.0.4
                        
                        if (currentInvoiceNo == previousInvoiceNo || invln == 1) // || previousInvoiceNo.Length == 0)
                        {
                            previousInvoiceNo = currentInvoiceNo;
                        }
                        else
                        {
                            processInvoiceLine();
                        }
                        invLines.AppendLine(invLine);
                        splitCSV = invLine.Split(',');

                        previousInvoiceNo = splitCSV[INV_POS];                  // invoice number
                        creditNote = splitCSV[CR_POS];                          // credit note number 1.0.4
                        previousInvoiceNo = previousInvoiceNo + creditNote;     // break on invoice number and credit note number 1.0.4
                        
                    }
                    
                    progressBarFiles.Value = invln;
                    this.Refresh();

                }

                if (invLines.Length > 0)
                {
                    processInvoiceLine();
                }


                // check for success of connecting to the REST web service
                // if 'success', moving to 'archive' folder - 1.0.4
                if (returnValue.Contains("OK"))
                {
                    if (checkBoxMoveFiles.Checked == true)
                    {
                        moveFile(sourceFile, destinationFile);
                    }
                }
                else
                {
                    // 1.0.4
                    if (checkBoxMoveFiles.Checked == true)
                    {
                        moveFile(sourceFile, failureDirectory);
                    }

                    
                }

                
            }

        }

        private void processInvoiceLine()
        {

            //contents = "<adjustment><binfrom>10</binfrom><qty>20</qty><binto>30</binto>";
            //contents = "customsearchrestquery";
            contents = "<stockitemexist>1234</stockitemexist>";

            contents = encodeXML(contents);

            invLines.Remove(0, invLines.Length);    // clear all buffer lines
            previousInvoiceNo = "";                 // clear previous invoice number


            // call the rest web service to transfer the payload
            contents = "{\"recordtype\":\"customer\",\"contents\":\"" + contents + "\"}";

            richTextBoxWebServiceResult.Text = consumeRESTWebService(contents);
         

        }

        //***********************************************
        // move the file to the 
        //***********************************************
        private void moveFile(string sourceFile, string destinationFile)
        {
            try
            {
                System.IO.File.Move(sourceFile, destinationFile);
            }
            catch (Exception e)
            {

            }
        }

        //***********************************************
        // load a file into a string
        //***********************************************
        private string readFileContents(string fileToRead)
        {
            string contents = "";

            // Read the file as one string.
            System.IO.StreamReader ftr = new System.IO.StreamReader(@fileToRead);
            contents = ftr.ReadToEnd();
            ftr.Close();

            return contents;
        }


        //***********************************************
        // call the netsuite rest web service
        //***********************************************
        private string consumeRESTWebService(string content)
        {

            string responseMessage = "";

            try
            {
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(@URL);
                request.Method = "POST";

                byte[] byteArray = Encoding.UTF8.GetBytes(content);

                String authorization = "NLAuth nlauth_account=" + account + ", nlauth_email=" + email + ",nlauth_signature=" + password + ", nlauth_role=" + role + "";
                request.Headers[HttpRequestHeader.Authorization] = authorization;
                request.Accept = "*.*";
                request.ContentType = "application/json";
                request.ContentLength = byteArray.Length;

                //request.ContentType = "text/plain";


                Stream dataStream = request.GetRequestStream();
                dataStream.Write(byteArray, 0, byteArray.Length);
                dataStream.Close();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                if (HttpStatusCode.OK == response.StatusCode)
                {
                    dataStream = response.GetResponseStream();
                    StreamReader reader = new StreamReader(dataStream);

                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        responseMessage = line.ToString();
                    }
                    dataStream.Close();
                    response.Close();
                }
                else
                {
                    responseMessage = "Web Service return code not OK " + response.StatusCode;

                }
            }
            catch (Exception ex)
            {
                responseMessage = ex.Message.ToString();
            }

            return responseMessage;
        }

        //*********************************************
        // encode xml
        //*********************************************
        private string encodeXML(string xml)
        {
            string retVal="";

            retVal = xml
                .Replace("&", "&amp;")
                .Replace("<", "&lt;")
                .Replace(">", "&gt;")
                .Replace("\"", "&quot;")
                .Replace("'", "&apos;")
                .Replace("\r", "&#xD;")
                .Replace("\n", "&#xA;"); 


            return retVal;
        }

        //*********************************************
        // button clicks
        //*********************************************
        private void buttonOnce_Click(object sender, EventArgs e)
        {
            progressBarFiles.Value = 0;
            //processFiles();
            processInvoiceLine();
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            interval = Convert.ToInt32(textBoxTimer.Text);
            timerSchedule.Interval = interval * 60 * 1000;
            timerSchedule.Enabled = true;
            buttonStart.Text = "Schedule Running";
            timerSchedule.Tick += new System.EventHandler(timerSchedule_Tick);

            timerSchedule.Start();

        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            timerSchedule.Enabled = false;
            buttonStart.Text = "Start Schedule";
            timerSchedule.Stop();


        }

        //********************************************
        // create Directory If It Does Not Exist
        //********************************************

        private void createDirectoryIfItDoesNotExist(string directoryName)
        {

            // Specify the directory you want to manipulate.
            string path = directoryName;

            try
            {
                // Determine whether the directory exists.
                if (Directory.Exists(path) == false)
                {
                    // Try to create the directory.
                    DirectoryInfo di = Directory.CreateDirectory(path);
                    MessageBox.Show("The directory " + directoryName + " was created successfully at " + Directory.GetCreationTime(path));
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Create directory has failed");
            }


        }
       

        //********************************************
        // timer schedule
        //********************************************

        private void timerSchedule_Tick(object sender, EventArgs e)
        {
            processFiles();
        }


         
  
    }
}
