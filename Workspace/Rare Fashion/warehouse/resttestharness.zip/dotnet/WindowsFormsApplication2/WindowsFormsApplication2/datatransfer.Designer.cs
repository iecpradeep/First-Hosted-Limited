﻿namespace WindowsFormsApplicationRESTDataTransfer
{
    partial class FormXMLImport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormXMLImport));
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonOnce = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxDirectoryToProcess = new System.Windows.Forms.TextBox();
            this.richTextBoxXML = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxWebService = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxMode = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.richTextBoxWebServiceResult = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxTimer = new System.Windows.Forms.TextBox();
            this.progressBarFiles = new System.Windows.Forms.ProgressBar();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxFileName = new System.Windows.Forms.TextBox();
            this.checkBoxMoveFiles = new System.Windows.Forms.CheckBox();
            this.timerSchedule = new System.Windows.Forms.Timer(this.components);
            this.richTextBoxInvLines = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(510, 556);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(108, 34);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start Schedule";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonOnce
            // 
            this.buttonOnce.Location = new System.Drawing.Point(396, 556);
            this.buttonOnce.Name = "buttonOnce";
            this.buttonOnce.Size = new System.Drawing.Size(108, 34);
            this.buttonOnce.TabIndex = 1;
            this.buttonOnce.Text = "Run Once";
            this.buttonOnce.UseVisualStyleBackColor = true;
            this.buttonOnce.Click += new System.EventHandler(this.buttonOnce_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(624, 556);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(108, 34);
            this.buttonStop.TabIndex = 2;
            this.buttonStop.Text = "Stop Schedule";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Directory to process";
            // 
            // textBoxDirectoryToProcess
            // 
            this.textBoxDirectoryToProcess.Location = new System.Drawing.Point(119, 6);
            this.textBoxDirectoryToProcess.Name = "textBoxDirectoryToProcess";
            this.textBoxDirectoryToProcess.Size = new System.Drawing.Size(422, 20);
            this.textBoxDirectoryToProcess.TabIndex = 4;
            // 
            // richTextBoxXML
            // 
            this.richTextBoxXML.Location = new System.Drawing.Point(119, 65);
            this.richTextBoxXML.Name = "richTextBoxXML";
            this.richTextBoxXML.Size = new System.Drawing.Size(613, 231);
            this.richTextBoxXML.TabIndex = 5;
            this.richTextBoxXML.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "CSV File Contents";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 314);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Web Service";
            // 
            // textBoxWebService
            // 
            this.textBoxWebService.Location = new System.Drawing.Point(119, 311);
            this.textBoxWebService.Name = "textBoxWebService";
            this.textBoxWebService.Size = new System.Drawing.Size(613, 20);
            this.textBoxWebService.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 353);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Mode";
            // 
            // textBoxMode
            // 
            this.textBoxMode.Location = new System.Drawing.Point(119, 353);
            this.textBoxMode.Name = "textBoxMode";
            this.textBoxMode.Size = new System.Drawing.Size(100, 20);
            this.textBoxMode.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 449);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Web Service Result";
            // 
            // richTextBoxWebServiceResult
            // 
            this.richTextBoxWebServiceResult.Location = new System.Drawing.Point(119, 446);
            this.richTextBoxWebServiceResult.Name = "richTextBoxWebServiceResult";
            this.richTextBoxWebServiceResult.Size = new System.Drawing.Size(613, 57);
            this.richTextBoxWebServiceResult.TabIndex = 12;
            this.richTextBoxWebServiceResult.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(547, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Timer Interval";
            // 
            // textBoxTimer
            // 
            this.textBoxTimer.Location = new System.Drawing.Point(632, 9);
            this.textBoxTimer.Name = "textBoxTimer";
            this.textBoxTimer.Size = new System.Drawing.Size(100, 20);
            this.textBoxTimer.TabIndex = 14;
            // 
            // progressBarFiles
            // 
            this.progressBarFiles.Location = new System.Drawing.Point(119, 512);
            this.progressBarFiles.Name = "progressBarFiles";
            this.progressBarFiles.Size = new System.Drawing.Size(613, 23);
            this.progressBarFiles.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "File to prorcess";
            // 
            // textBoxFileName
            // 
            this.textBoxFileName.Location = new System.Drawing.Point(119, 35);
            this.textBoxFileName.Name = "textBoxFileName";
            this.textBoxFileName.Size = new System.Drawing.Size(250, 20);
            this.textBoxFileName.TabIndex = 17;
            // 
            // checkBoxMoveFiles
            // 
            this.checkBoxMoveFiles.AutoSize = true;
            this.checkBoxMoveFiles.Checked = true;
            this.checkBoxMoveFiles.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxMoveFiles.Location = new System.Drawing.Point(256, 353);
            this.checkBoxMoveFiles.Name = "checkBoxMoveFiles";
            this.checkBoxMoveFiles.Size = new System.Drawing.Size(86, 17);
            this.checkBoxMoveFiles.TabIndex = 18;
            this.checkBoxMoveFiles.Text = "Archive Files";
            this.checkBoxMoveFiles.UseVisualStyleBackColor = true;
            // 
            // timerSchedule
            // 
            this.timerSchedule.Tick += new System.EventHandler(this.timerSchedule_Tick);
            // 
            // richTextBoxInvLines
            // 
            this.richTextBoxInvLines.Location = new System.Drawing.Point(119, 379);
            this.richTextBoxInvLines.Name = "richTextBoxInvLines";
            this.richTextBoxInvLines.Size = new System.Drawing.Size(613, 56);
            this.richTextBoxInvLines.TabIndex = 19;
            this.richTextBoxInvLines.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 382);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "Invoice Payload";
            // 
            // FormXMLImport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(757, 607);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.richTextBoxInvLines);
            this.Controls.Add(this.checkBoxMoveFiles);
            this.Controls.Add(this.textBoxFileName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.progressBarFiles);
            this.Controls.Add(this.textBoxTimer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.richTextBoxWebServiceResult);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxMode);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxWebService);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.richTextBoxXML);
            this.Controls.Add(this.textBoxDirectoryToProcess);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonOnce);
            this.Controls.Add(this.buttonStart);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormXMLImport";
            this.Text = "NetSuite Data Import Service";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonOnce;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxDirectoryToProcess;
        private System.Windows.Forms.RichTextBox richTextBoxXML;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxWebService;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxMode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox richTextBoxWebServiceResult;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxTimer;
        private System.Windows.Forms.ProgressBar progressBarFiles;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxFileName;
        private System.Windows.Forms.CheckBox checkBoxMoveFiles;
        private System.Windows.Forms.Timer timerSchedule;
        private System.Windows.Forms.RichTextBox richTextBoxInvLines;
        private System.Windows.Forms.Label label8;
    }
}

